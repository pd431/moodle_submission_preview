Run main.py
